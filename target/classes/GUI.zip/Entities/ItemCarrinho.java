package Entities;

// ItemCarrinho.java
public interface ItemCarrinho {
    double getPreco();
    String getDescricao();

}
