package Aplication;

import GUI.VaptVuptGUI;
import GUI.VaptVuptGUIAdmin;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

            VaptVuptGUI vaptVuptGUI = new VaptVuptGUI();

    }
}
