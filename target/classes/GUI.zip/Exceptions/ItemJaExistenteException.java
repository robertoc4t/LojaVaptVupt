package Exceptions;

public class ItemJaExistenteException extends Exception {
    public ItemJaExistenteException(String msg) {
        super(msg);
    }
}
