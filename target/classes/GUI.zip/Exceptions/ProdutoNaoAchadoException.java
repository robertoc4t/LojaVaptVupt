package Exceptions;

public class ProdutoNaoAchadoException extends Exception {
    public ProdutoNaoAchadoException(String msg) {
        super(msg);
    }
}
